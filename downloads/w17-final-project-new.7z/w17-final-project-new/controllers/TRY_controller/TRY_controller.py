from controller import Robot, Keyboard, GPS, InertialUnit
import math

# ================== 參數初始化 ==================
WHEEL_RADIUS = 0.1
L = 0.471
W = 0.376
MAX_VELOCITY = 10.0
TIME_STEP = 16

score_to_send = 2
cooldown = 1.0

def clamp_angle(angle):
    return (angle + math.pi) % (2 * math.pi) - math.pi

def passive_wait(robot, sec):
    start_time = robot.getTime()
    while robot.getTime() - start_time < sec:
        if robot.step(int(robot.getBasicTimeStep())) == -1:
            break

# ================== 主程式 ==================
robot = Robot()
timestep = int(robot.getBasicTimeStep())

# 控制裝置
emitter = robot.getDevice("score_emitter")
sensor = robot.getDevice('sensor')
sensor.enable(timestep)
score = 0
last_score_time = 0

keyboard = Keyboard()
keyboard.enable(timestep)

# 馬達
wheel5 = robot.getDevice("wheel5")  # Front-right
wheel6 = robot.getDevice("wheel6")  # Front-left
wheel7 = robot.getDevice("wheel7")  # Rear-right
wheel8 = robot.getDevice("wheel8")  # Rear-left
for wheel in [wheel5, wheel6, wheel7, wheel8]:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0)

def set_wheel_velocity(v1, v2, v3, v4):
    wheel5.setVelocity(v1)
    wheel6.setVelocity(v2)
    wheel7.setVelocity(v3)
    wheel8.setVelocity(v4)

lookup_table = [
    (1000, 0.00),
    (620, 0.12),
    (372, 0.13),
    (248, 0.14),
    (186, 0.15),
    (0, 0.18)
]

def ad_to_distance(ad_value):
    for i in range(len(lookup_table)-1):
        a0, d0 = lookup_table[i]
        a1, d1 = lookup_table[i+1]
        if a1 <= ad_value <= a0:
            return d0 + (d1 - d0) * (ad_value - a0) / (a1 - a0)
    if ad_value > lookup_table[0][0]:
        return lookup_table[0][1]
    return lookup_table[-1][1]

# ==== IMU/GPS 初始化 ====
imu = robot.getDevice("inertial unit")
imu.enable(timestep)
gps = robot.getDevice("gps")
gps.enable(timestep)
wheel_names = ["wheel5", "wheel6", "wheel7", "wheel8"]
wheels = [robot.getDevice(name) for name in wheel_names]
for w in wheels:
    w.setPosition(float('inf'))

for _ in range(10):
    robot.step(timestep)

def get_yaw():
    return imu.getRollPitchYaw()[2]

def get_position():
    pos = gps.getValues()
    return (pos[0], pos[1])

def angle_diff(a, b):
    d = a - b
    while d > math.pi:
        d -= 2 * math.pi
    while d < -math.pi:
        d += 2 * math.pi
    return d

def angle_between_vectors(ax, ay, bx, by):
    norm_a = math.hypot(ax, ay)
    norm_b = math.hypot(bx, by)
    if norm_a == 0 or norm_b == 0:
        return 0
    ax, ay = ax / norm_a, ay / norm_a
    bx, by = bx / norm_b, by / norm_b
    dot = ax * bx + ay * by
    det = ax * by - ay * bx
    angle_rad = math.atan2(det, dot)
    angle_deg = math.degrees(angle_rad)
    return angle_deg

def rotate_by_angle(target_angle_deg, fast_velocity=MAX_VELOCITY, slow_velocity=1.0, tolerance_deg=0.05):
    start_yaw = get_yaw()
    target_rad = math.radians(target_angle_deg)
    slow_zone = math.radians(5)
    direction = -1 if target_angle_deg > 0 else 1

    set_wheel_velocity(-direction*fast_velocity, direction*fast_velocity,
                       -direction*fast_velocity, direction*fast_velocity)

    while True:
        robot.step(timestep)
        now_yaw = get_yaw()
        turned = angle_diff(now_yaw, start_yaw)
        remain = abs(target_rad) - abs(turned)
        if remain < slow_zone:
            set_wheel_velocity(-direction*slow_velocity, direction*slow_velocity,
                               -direction*slow_velocity, direction*slow_velocity)
        if remain < math.radians(tolerance_deg):
            break

    set_wheel_velocity(0, 0, 0, 0)
    print(f"Yaw changed by {math.degrees(turned):.5f} degrees")

def move_to_point_and_face_to(target_point, face_to_point, MAX_VELOCITY=10.0, tolerance_pos=0.01):
    fast_velocity=10.0
    slow_velocity=1.0
    # --- 1. 先轉向目標點 ---
    now_pos = get_position()
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    tar_vec = (target_point[0] - now_pos[0], target_point[1] - now_pos[1])
    rotate_angle = angle_between_vectors(head_vec[0], head_vec[1], tar_vec[0], tar_vec[1])
    print(f"第一段應旋轉 {rotate_angle:.3f} 度")
    rotate_by_angle(rotate_angle)

    # --- 2. 前進到目標點 ---
    while True:
        robot.step(timestep)
        now_pos = get_position()
        dx = target_point[0] - now_pos[0]
        dz = target_point[1] - now_pos[1]
        dist = math.hypot(dx, dz)
        if dist < tolerance_pos:
            break
        v = fast_velocity if dist > 0.2 else slow_velocity
        set_wheel_velocity(v, v, v, v)
    set_wheel_velocity(0, 0, 0, 0)
    now_pos = get_position()

    # --- 3. 轉向 face_to_point ---
    yaw = get_yaw()
    head_vec = (math.cos(yaw), math.sin(yaw))
    face_vec = (face_to_point[0] - now_pos[0], face_to_point[1] - now_pos[1])
    rotate_angle = angle_between_vectors(head_vec[0], head_vec[1], face_vec[0], face_vec[1])
    print(f"第二段應旋轉 {rotate_angle:.3f} 度")
    rotate_by_angle(rotate_angle)

# ==== 按鍵說明 ====
print("Use 'W', 'S', 'A', 'D' keys to control the robot.")
print("F: 順時針旋轉90度，G: 逆時針旋轉90度，C: 回歸 (6.23,-0.18) 並朝向原點")
print("Q: 離開")

while robot.step(timestep) != -1:
    key = keyboard.getKey()
    sensor_value = sensor.getValue()
    distance = ad_to_distance(sensor_value)
    current_time = robot.getTime()

    if key == ord('M') or key == ord('m'):
        print(distance)
    if key == ord('K') or key == ord('k'):
        print(distance)

    if distance < 0.11 and (current_time - last_score_time) > cooldown:
        score += score_to_send
        print("得分")
        print(distance)
        emitter.send(str(score_to_send).encode('utf-8'))
        last_score_time = current_time

    # === 一般鍵盤控制 ===
    if key == ord('W') or key == ord('w'):
        set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
    elif key == ord('S') or key == ord('s'):
        set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
    elif key == ord('D') or key == ord('d'):
        set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
    elif key == ord('A') or key == ord('a'):
        set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
    elif key == ord('F') or key == ord('f'):
        print("Rotating +90 degrees (clockwise)")
        before_yaw = imu.getRollPitchYaw()[2]
        print(before_yaw)
        rotate_by_angle(90)
        after_yaw = imu.getRollPitchYaw()[2]
        print(after_yaw)
        delta_yaw_deg = (after_yaw - before_yaw)/ (math.pi/180)
        print(f"Yaw changed by {delta_yaw_deg:.5f} degrees")
    elif key == ord('G') or key == ord('g'):
        print("Rotating -90 degrees (counterclockwise)")
        rotate_by_angle(-90)
    elif key == ord('C') or key == ord('c'):
        print("Moving to (6.23,-0.18) and facing to (0,0)")
        move_to_point_and_face_to((6.23, -0.18), (10.0, 0.0))
    elif key == ord('Q') or key == ord('q'):
        print("Exiting...")
        break
    else:
        set_wheel_velocity(0, 0, 0, 0)